package com.example.project3vanderwilt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class WeightEntryActivity extends AppCompatActivity {
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;
    EditText weightEntry, dateEntry;
    DBHelper dBHelper;
    // variable for shared preferences.
    SharedPreferences sharedpreferences;
    public static final String SHARED_PREFS = "shared_prefs";
    // key for storing id
    public static final String ID_KEY = "userid_key";
    // key for storing goal
    public static final String GOAL_KEY = "goal_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_entry);

        weightEntry = findViewById(R.id.daily_weight);
        dateEntry = findViewById(R.id.editTextDate);
        Button submitButton = findViewById(R.id.weight_submit_button);
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);


        dBHelper = new DBHelper(this);
        // initializing our shared preferences.
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
        submitButton.setOnClickListener(view -> {
            try {
                if (dBHelper.addWeight(sharedpreferences.getString(ID_KEY, null), dateEntry.getText().toString(),
                        weightEntry.getText().toString())) {
                    Toast.makeText(this, "Weight entry added", Toast.LENGTH_LONG).show();
                    if (sharedpreferences.getString(GOAL_KEY, null).equals(weightEntry.getText().toString())) {
                        sendSMSMessage();
                    }
                    finish();
                } else {
                    Toast.makeText(this, "Only 1 entry per day.  Please delete or edit current entry.", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Error adding weight.", Toast.LENGTH_LONG).show();
                System.out.println(e.getMessage());
            }
        });
    }

    //method to send SMS message once goal has been met
    protected void sendSMSMessage() {
        TelephonyManager telephonyManager = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_NUMBERS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        String phoneNumber = telephonyManager.getLine1Number();
        String message = "Congrats on making your goal!";

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        } else {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phoneNumber, null, message, null, null);
        }
    }
}