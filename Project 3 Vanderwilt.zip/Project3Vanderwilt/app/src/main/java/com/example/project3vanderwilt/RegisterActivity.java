package com.example.project3vanderwilt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    EditText Email, Password, FirstName, LastName ;
    Button Register;
    Boolean EditTextEmptyHolder;
    DBHelper dBHelper;
    String F_Result = "Not_Found";
    SharedPreferences sharedpreferences;
    // creating constant keys for shared preferences.
    public static final String SHARED_PREFS = "shared_prefs";
    // key for storing email.
    public static final String EMAIL_KEY = "email_key";
    // key for storing password.
    public static final String PASSWORD_KEY = "password_key";
    // key for storing first name
    public static final String FIRST_KEY = "firstname_key";
    // key for storing last name
    public static final String LAST_KEY = "lastname_key";
    // key for storing goal
    public static final String GOAL_KEY = "goal_key";
    // key for storing id
    public static final String ID_KEY = "userid_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
        Register = (Button)findViewById(R.id.buttonRegister);

        Email = (EditText)findViewById(R.id.editEmail);
        Password = (EditText)findViewById(R.id.editPassword);
        FirstName = (EditText)findViewById(R.id.editFirstName);
        LastName = (EditText)findViewById(R.id.editLastName);

        dBHelper = new DBHelper(this);

        // Adding click listener to register button.
        Register.setOnClickListener(view -> {

            // Checking EditText is empty or Not.
            CheckEditTextStatus();

            // Method to check Email is already exists or not.
            CheckingEmailAlreadyExistsOrNot();

            // Empty EditText After done inserting process.
            EmptyEditTextAfterDataInsert();


        });

    }

    // Insert data into SQLite database method.
    public void InsertDataIntoSQLiteDatabase(){

        // If editText is not empty then this block will executed.
        if(EditTextEmptyHolder)
        {
            int userId = dBHelper.addUser(FirstName.getText().toString(),LastName.getText().toString(),
                    Email.getText().toString(), Password.getText().toString());

            if (userId != -1) {

                SharedPreferences.Editor editor = sharedpreferences.edit();
                // put values for shared preferences.
                editor.putString(EMAIL_KEY, Email.getText().toString());
                editor.putString(PASSWORD_KEY, Password.getText().toString());
                editor.putString(FIRST_KEY, FirstName.getText().toString());
                editor.putString(LAST_KEY, LastName.getText().toString());
                editor.putString(GOAL_KEY, "0.0");
                editor.putInt(ID_KEY, userId);
                // to save our data with key and value.
                editor.apply();
                // Printing toast message after done inserting.
                Toast.makeText(RegisterActivity.this, "User Registered Successfully", Toast.LENGTH_LONG).show();
                //Open main activity
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);

            }
            else {
                System.out.println("Error setting up user");
                Toast.makeText(RegisterActivity.this, "Error creating user", Toast.LENGTH_LONG).show();
            }

        }
        // This block will execute if any of the registration EditText is empty.
        else {
            // Printing toast message if any of EditText is empty.
            Toast.makeText(RegisterActivity.this,"Please Fill All The Required Fields.", Toast.LENGTH_LONG).show();
        }

    }

    // Empty edittext after done inserting process method.
    public void EmptyEditTextAfterDataInsert(){

        FirstName.getText().clear();
        LastName.getText().clear();
        Email.getText().clear();

        Password.getText().clear();

    }

    // Method to check EditText is empty or Not.
    public void CheckEditTextStatus(){

        // Getting value from All EditText and storing into String Variables.
        EditTextEmptyHolder = !TextUtils.isEmpty(FirstName.getText().toString()) && !TextUtils.isEmpty(LastName.getText().toString()) &&
                !TextUtils.isEmpty(Email.getText().toString()) && !TextUtils.isEmpty(Password.getText().toString());
    }

    // Checking Email is already exists or not.
    public void CheckingEmailAlreadyExistsOrNot(){

        if (dBHelper.checkUsername(Email.getText().toString())){
            // If Email is already exists then Result variable value set as Email Found.
            F_Result = "Email Found";
        }

        // Calling method to check final result and insert data into SQLite database.
        CheckFinalResult();

    }


    // Checking result
    public void CheckFinalResult(){

        // Checking whether email is already exists or not.
        if(F_Result.equalsIgnoreCase("Email Found"))
        {
            // If email is exists then toast msg will display.
            Toast.makeText(RegisterActivity.this,"Email Already Exists",Toast.LENGTH_LONG).show();
        }
        else {

            // If email already dose n't exists then user registration details will entered to SQLite database.
            InsertDataIntoSQLiteDatabase();
        }

        F_Result = "Not_Found" ;

    }

}