package com.example.project3vanderwilt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserSettingActivity extends AppCompatActivity {
    //permission codes
    private static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
    // creating constant keys for shared preferences.
    public static final String SHARED_PREFS = "shared_prefs";
    // key for storing email.
    public static final String FIRST_KEY = "firstname_key";
    // key for storing last name
    public static final String LAST_KEY = "lastname_key";
    // key for storing goal
    public static final String GOAL_KEY = "goal_key";
    // key for storing id
    public static final String ID_KEY = "userid_key";
    SharedPreferences sharedpreferences;
    DBHelper dBHelper;
    EditText firstName, lastName, goalWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_setting);
        firstName = findViewById(R.id.first_name_settings);
        lastName = findViewById(R.id.last_name_settings);
        goalWeight = findViewById(R.id.goal_weight);

            sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
        // set all values to current values
        firstName.setText(sharedpreferences.getString(FIRST_KEY, null));
        lastName.setText(sharedpreferences.getString(LAST_KEY, null));
        goalWeight.setText(sharedpreferences.getString(GOAL_KEY,null));
        Button submitSettings = findViewById(R.id.submit_button);
        SwitchCompat smsSetting = findViewById(R.id.notification_switch);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED) {
            System.out.println("It's true baby");
            smsSetting.setChecked(true);
        } else {
            System.out.println("Its a lie");
        }
        dBHelper = new DBHelper(this);

        submitSettings.setOnClickListener(view -> {
            if (dBHelper.updateUser(sharedpreferences.getString(ID_KEY,null), firstName.getText().toString(), lastName.getText().toString(),
                    goalWeight.getText().toString())) {
                SharedPreferences.Editor editor = sharedpreferences.edit();
                // put values for shared preferences.
                editor.putString(FIRST_KEY, firstName.getText().toString());
                editor.putString(LAST_KEY, lastName.getText().toString());
                editor.putString(GOAL_KEY, goalWeight.getText().toString());
                // to save our data with key and value.
                editor.apply();
                Toast.makeText(this, "User Settings Updated", Toast.LENGTH_LONG).show();
                Intent i = new Intent(UserSettingActivity.this, MainActivity.class);
                startActivity(i);
                finish();
            } else {
                Toast.makeText(this,"Error updating user", Toast.LENGTH_LONG).show();
            }
        });

        smsSetting.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                checkAndRequestPermissions();
            } else {
                smsSetting.setChecked(true);
                new AlertDialog.Builder(this)
                        .setMessage("Remove permissions in settings")
                        .setPositiveButton("OK", null)
                        .create()
                        .show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        // Checking the request code of our request
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_ID_MULTIPLE_PERMISSIONS) {
            Map<String, Integer> perms = new HashMap<>();
            perms.put(Manifest.permission.SEND_SMS, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.READ_PHONE_NUMBERS, PackageManager.PERMISSION_GRANTED);

            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++) {
                    perms.put(permissions[i], grantResults[i]);
                    //check for both permissions
                    if (perms.get(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED &&
                            perms.get(Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "Permissions granted", Toast.LENGTH_LONG).show();
                    } else {
                        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS) ||
                                ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_PHONE_NUMBERS)) {
                            showDialogOK((dialog, which) -> {

                                switch (which) {
                                    case DialogInterface.BUTTON_POSITIVE:
                                        checkAndRequestPermissions();
                                        break;

                                    case DialogInterface.BUTTON_NEGATIVE:
                                        // proceed with logic by disabling the related features or quit the app.
                                        break;
                                }
                            });
                        } else {
                            Toast.makeText(this, "Go to settings and enable permissions", Toast.LENGTH_LONG).show();
                            //                            //proceed with logic by disabling the related features or quit the app.
                        }


                    }
                }
            }
        }
    }

    private boolean checkAndRequestPermissions() {
        int permissionSendMessage = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        int permissionPhone = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_NUMBERS);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (permissionPhone != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_PHONE_NUMBERS);
        }
        if (permissionSendMessage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.SEND_SMS);
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[0]),
                    REQUEST_ID_MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;
    }

    private void showDialogOK(DialogInterface.OnClickListener okListener) {

        new AlertDialog.Builder(this)
                .setMessage("To fully utilize this app, enable text messages")
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", okListener)
                .create()
                .show();
    }
}