package com.example.project3vanderwilt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    Button LogInButton, RegisterButton ;
    EditText Email, Password ;
    String EmailHolder, PasswordHolder;
    Boolean EditTextEmptyHolder;
    DBHelper dBHelper;
    SharedPreferences sharedpreferences;
    // creating constant keys for shared preferences.
    public static final String SHARED_PREFS = "shared_prefs";
    // key for storing email.
    public static final String EMAIL_KEY = "email_key";
    // key for storing password.
    public static final String PASSWORD_KEY = "password_key";
    // key for storing first name
    public static final String FIRST_KEY = "firstname_key";
    // key for storing last name
    public static final String LAST_KEY = "lastname_key";
    // key for storing goal
    public static final String GOAL_KEY = "goal_key";
    // key for storing id
    public static final String ID_KEY = "userid_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        // initializing our shared preferences.
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);

        // getting data from shared prefs and
        // storing it in our string variable.
        EmailHolder = sharedpreferences.getString(EMAIL_KEY, null);
        PasswordHolder = sharedpreferences.getString(PASSWORD_KEY, null);

        LogInButton = (Button)findViewById(R.id.login);

        RegisterButton = (Button)findViewById(R.id.register);

        Email = (EditText)findViewById(R.id.username);
        Password = (EditText)findViewById(R.id.password);

        dBHelper = new DBHelper(this);
        //Adding click listener to log in button.
        LogInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Calling EditText is empty or no method.
                CheckEditTextStatus();

                // Calling login method.
                LoginFunction();
            }
        });

        // Adding click listener to register button.
        RegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Opening new user registration activity using intent on button click.
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);


            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (EmailHolder != null && PasswordHolder != null) {
            Intent i = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(i);
        }
    }

    // Login function starts from here.
    public void LoginFunction(){

        if(EditTextEmptyHolder) {
            Map<String,String> map = dBHelper.checkUsernamePassword(EmailHolder, PasswordHolder);
            if (map != null) {
                Toast.makeText(LoginActivity.this,"Login Successful",Toast.LENGTH_LONG).show();
                SharedPreferences.Editor editor = sharedpreferences.edit();

                // below two lines will put values for
                // email and password in shared preferences.
                editor.putString(EMAIL_KEY, map.get("email"));
                editor.putString(PASSWORD_KEY, map.get("password"));
                editor.putString(FIRST_KEY, map.get("firstname"));
                editor.putString(LAST_KEY, map.get("lastname"));
                editor.putString(GOAL_KEY, map.get("goal"));
                editor.putString(ID_KEY, map.get("userID"));

                // to save our data with key and value.
                editor.apply();
                // Going to Dashboard activity after login success message.
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);

                startActivity(intent);
            }
            else {
                Toast.makeText(LoginActivity.this,"UserName or Password is Wrong, Please Try Again.",Toast.LENGTH_LONG).show();
            }
        }
        else {

            //If any of login EditText empty then this block will be executed.
            Toast.makeText(LoginActivity.this,"Please Enter UserName or Password.",Toast.LENGTH_LONG).show();

        }

    }

    // Checking EditText is empty or not.
    public void CheckEditTextStatus(){

        // Getting value from All EditText and storing into String Variables.
        EmailHolder = Email.getText().toString();
        PasswordHolder = Password.getText().toString();

        // Checking EditText is empty or no using TextUtils.
        EditTextEmptyHolder = !( TextUtils.isEmpty(EmailHolder) || TextUtils.isEmpty(PasswordHolder));
    }
}