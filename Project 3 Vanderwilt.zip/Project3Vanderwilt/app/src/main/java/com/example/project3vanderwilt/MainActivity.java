package com.example.project3vanderwilt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {


    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS =0 ;
    // creating constant keys for shared preferences.
    public static final String SHARED_PREFS = "shared_prefs";

    // key for storing email.
    public static final String EMAIL_KEY = "email_key";
    public static final String FIRST_KEY = "firstname_key";


    // variable for shared preferences.
    SharedPreferences sharedpreferences;
    String email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView Email = (TextView)findViewById(R.id.textView1);
        Button LogOUT = (Button)findViewById(R.id.button1);
        Button editSettings = (Button)findViewById(R.id.settings_button);
        Button viewData = (Button)findViewById(R.id.view_data_button);
        Button addWeight = (Button)findViewById(R.id.add_weight_button);

        // initializing our shared preferences.
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);

        // getting data from shared prefs and
        // storing it in our string variable.
        String name = sharedpreferences.getString(FIRST_KEY, null);
        Email.setText("Welcome \n" + name);
        // Adding click listener to Log Out button.
        LogOUT.setOnClickListener(view -> {
            // calling method to edit values in shared prefs.
            SharedPreferences.Editor editor = sharedpreferences.edit();
            // below line will clear
            // the data in shared prefs.
            editor.clear();
            // below line will apply empty
            // data to shared prefs.
            editor.apply();
            // starting mainactivity after
            // clearing values in shared preferences.
            Intent i = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(i);
            finish();
            Toast.makeText(MainActivity.this,"Log Out Successful", Toast.LENGTH_LONG).show();
        });
        // add onclicklistener to editSettings button
        editSettings.setOnClickListener(view -> {
            Intent i = new Intent(MainActivity.this, UserSettingActivity.class);
            startActivity(i);
            finish();
        });
        // add onclicklistener to viewData button
        viewData.setOnClickListener(view -> {
            Intent i = new Intent(MainActivity.this, DataGridActivity.class);
            startActivity(i);
        });
        // add onclicklistener to addWeight button
        addWeight.setOnClickListener(view -> {
            Intent i = new Intent(MainActivity.this, WeightEntryActivity.class);
            startActivity(i);
        });

    }
}