package com.example.project3vanderwilt;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DBHelper extends SQLiteOpenHelper {
    static String DATABASE_NAME="UserDataBase";

    public static final String USER_TABLE_NAME="UserTable";
    public static final String WEIGHT_TABLE_NAME="WeightTable";

    // fields for user table
    public static final String USER_Id="id";
    public static final String USER_FirstName="first_name";
    public static final String USER_LastName="last_name";
    public static final String USER_Email="email";
    public static final String USER_Password="password";
    public static final String USER_GoalWeight="goal";

    // fields for weight table
    public static final String WEIGHT_Id="id";
    public static final String WEIGHT_Date="date";
    public static final String WEIGHT_Weight="weight";
    public static final String WEIGHT_UserId="userID";
    //constructor
    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    //create tables in the database
    @Override
    public void onCreate(SQLiteDatabase database) {

        String CREATE_USER_TABLE="CREATE TABLE IF NOT EXISTS "+USER_TABLE_NAME+" ("+USER_Id+" INTEGER PRIMARY KEY AUTOINCREMENT, "+
                USER_FirstName+" TEXT NOT NULL, "+USER_LastName+" TEXT NOT NULL, "+USER_Email+" TEXT NOT NULL UNIQUE, "+
                USER_Password+" VARCHAR, "+USER_GoalWeight+" DOUBLE)";
        database.execSQL(CREATE_USER_TABLE);

        String CREATE_WEIGHT_TABLE="CREATE TABLE IF NOT EXISTS "+WEIGHT_TABLE_NAME+" ("+WEIGHT_Id+" INTEGER PRIMARY KEY AUTOINCREMENT, "+
                WEIGHT_Date+" TEXT NOT NULL, "+WEIGHT_Weight+" REAL NOT NULL, "+WEIGHT_UserId+" INTEGER)";
        database.execSQL(CREATE_WEIGHT_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+USER_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS "+WEIGHT_TABLE_NAME);
        onCreate(db);

    }

    // user table methods
    public int addUser(String first_name, String last_name, String email, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USER_FirstName, first_name);
        contentValues.put(USER_LastName, last_name);
        contentValues.put(USER_Email, email);
        contentValues.put(USER_Password, password);

        long result = MyDB.insert(USER_TABLE_NAME, null, contentValues);
        int userID = -1;
        if (result != -1) {
            String selectQuery = "SELECT " + USER_Id + " FROM " + USER_TABLE_NAME + " WHERE " + USER_Email +
                    " =  ? AND " + USER_Password + " = ?";
            Cursor cursor =MyDB.rawQuery(selectQuery, new String[] {email, password});
            if (cursor != null) {
                cursor.moveToFirst();
                userID = Integer.parseInt(cursor.getString(0));
                cursor.close();
            }
        }
        return userID;
    }

    public boolean checkUsername(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("SELECT * FROM " + USER_TABLE_NAME + " WHERE " +
                USER_Email +" = ?", new String[] {username} );
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    public Map<String,String> checkUsernamePassword(String username, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("SELECT * FROM " + USER_TABLE_NAME + " WHERE " +
                USER_Email + " = ? and " + USER_Password + " = ?", new String[] {username, password});
        Map<String,String> map = new HashMap<>();
        if (cursor != null) {
            cursor.moveToFirst();
            map.put("userID", cursor.getString(0));
            map.put("firstname", cursor.getString(1));
            map.put("lastname", cursor.getString(2));
            map.put("email", cursor.getString(3));
            map.put("password", cursor.getString(4));
            map.put("goal", cursor.getString(5));
            cursor.close();
        } else {
            map = null;
        }
        return map;
    }

    public boolean updateUser(String id, String firstName, String lastName, String goalWeight) {
        SQLiteDatabase MyDB = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USER_FirstName, firstName);
        contentValues.put(USER_LastName, lastName);
        contentValues.put(USER_GoalWeight, goalWeight);


        long result = MyDB.update(USER_TABLE_NAME, contentValues, USER_Id + " = ?", new String[]{id});
        return (result != -1);
    }

    /*public boolean addGoalWeight(String user_Id, Date date, Float weight) {
        if (addWeight(user_Id, date, weight)) {
            SQLiteDatabase db = this.getReadableDatabase();

            String selectQuery = "SELECT " + WEIGHT_Id + " FROM " + WEIGHT_TABLE_NAME + " WHERE " + WEIGHT_Date +
                    "= " + date + " AND " + WEIGHT_UserId + " = " + user_Id;
            Cursor cursor = db.rawQuery(selectQuery, null);
            @SuppressLint("Range") int goalID = cursor.getInt(cursor.getColumnIndex(WEIGHT_Id));
            cursor.close();
            ContentValues values = new ContentValues();
             values.put(USER_GoalWeightId, goalID);

             try {
                 db.update(USER_TABLE_NAME, values, USER_Id + "= ", new String[] {user_Id});
                 return true;
             } catch (Exception e) {
                 return false;
             }
        } else {
            return false;
        }


    }*/

    // Weight table
    public boolean addWeight(String user_Id, String date, String weight) {
        if (checkWeightDate(user_Id, date)) {
            SQLiteDatabase MyDB = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(WEIGHT_UserId, user_Id);
            contentValues.put(WEIGHT_Date, date);
            contentValues.put(WEIGHT_Weight, weight);

            long result = MyDB.insert(WEIGHT_TABLE_NAME, null, contentValues);
            return (result != -1);
        }
        return false;
    }
    private boolean checkWeightDate(String user_Id, String date) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("SELECT * FROM " + WEIGHT_TABLE_NAME + " WHERE " +
                WEIGHT_UserId +" = ? and " + WEIGHT_Date + " = ?", new String[] {user_Id, date} );
        int count = cursor.getCount();
        cursor.close();
        return count == 0;
    }
    public void deleteWeight(String weight_Id) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        MyDB.delete(WEIGHT_TABLE_NAME, WEIGHT_Id + " =?", new String[] {weight_Id});
        MyDB.close();
    }

    public boolean updateWeight(String weight_Id, String weight) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(WEIGHT_Weight, weight);

        long result = MyDB.update(WEIGHT_TABLE_NAME, contentValues, WEIGHT_Id + " = ?", new String[]{weight_Id});
        return (result != -1);
    }

    public ArrayList<Weight> getData(String user_Id) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ArrayList<Weight> arrayList = new ArrayList<>();
        Cursor cursor = MyDB.query(WEIGHT_TABLE_NAME, null,
                WEIGHT_UserId + "= ?", new String[]{user_Id},null,null,null );
        System.out.println(cursor.getCount());
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            do {
                arrayList.add(new Weight(cursor.getString(0), cursor.getString(1), cursor.getString(2),
                        cursor.getString(3)));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return arrayList;
    }
}
