package com.example.project3vanderwilt;

public class Weight {
    String _id;
    String _date;
    String _weight;
    String _userId;

    public Weight() {}

    public Weight(String id, String date, String weight, String userId) {
        this._id = id;
        this._date = date;
        this._weight = weight;
        this._userId = userId;
    }

    public Weight(String date, String weight) {
        this._weight = weight;
        this._date = date;
    }

    //setters
    public void setID(String id) {
        this._id = id;
    }

    public void setWeight(String weight) {
        this._weight = weight;
    }

    public void setDate(String date) {
        this._date = date;
    }

    //getters
    public String getWeight() {
        return this._weight;
    }

    public String getID() {
        return this._id;
    }

    public String getDate() {
        return this._date;
    }

}
