package com.example.project3vanderwilt;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class DataGridActivity extends AppCompatActivity {
    SharedPreferences sharedpreferences;
    public static final String SHARED_PREFS = "shared_prefs";
    // key for storing id
    public static final String ID_KEY = "userid_key";

    private TableLayout tableLayout;
    DBHelper dBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);
        tableLayout = findViewById(R.id.simpleTableLayout);
        tableLayout.setStretchAllColumns(true);
        dBHelper = new DBHelper(this);
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
        Button home = findViewById(R.id.home_button);
        Button addWeight = findViewById(R.id.add_weight_button);
        loadData();
        addWeight.setOnClickListener(view -> {
            Intent i = new Intent(DataGridActivity.this, WeightEntryActivity.class);
            startActivity(i);
            finish();
        });
        home.setOnClickListener(view -> {
            finish();
        });
    }


    public void loadData() {
        tableLayout.removeAllViews();
        ArrayList<Weight> arrayList = dBHelper.getData(sharedpreferences.getString(ID_KEY, null));
        if (arrayList.size() == 0) {
            final TextView empty = new TextView(this);
            empty.setText("No data to display");
            tableLayout.addView(empty);
        }
        for (int i = 0; i < arrayList.size(); i++) {
            TableRow tableRow = new TableRow(this);

            // add column for date
            final TextView tv = new TextView(this);

            tv.setLayoutParams(new
                    TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT,
                    TableRow.LayoutParams.WRAP_CONTENT));
            tv.setPadding(5, 15, 0, 15);
            tv.setText(arrayList.get(i).getDate());
            tableRow.addView(tv);
            // add column for weight
            final TextView tv2 = new TextView(this);
            tv2.setLayoutParams(new
                    TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT,
                    TableRow.LayoutParams.WRAP_CONTENT));
            tv2.setPadding(5, 15, 0, 15);
            tv2.setText(arrayList.get(i).getWeight());
            tableRow.addView(tv2);
            tableLayout.addView(tableRow);

            // add delete button to row
            Button delete = new Button(this);
            delete.setPadding(5, 15, 0, 15);
            delete.setText("Delete");
            delete.setLayoutParams(new
                    TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT,
                    TableRow.LayoutParams.WRAP_CONTENT));
            //delete.setGravity(Gravity.START);
            int finalI = i;
            delete.setOnClickListener(view -> {
                dBHelper.deleteWeight(arrayList.get(finalI).getID());
                loadData();
            });
            tableRow.addView(delete);

            // add edit button to row
            Button edit = new Button(this);
            edit.setPadding(5, 15, 0, 15);
            edit.setText("Edit");
            edit.setLayoutParams(new
                    TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT,
                    TableRow.LayoutParams.WRAP_CONTENT));

            edit.setOnClickListener(view -> {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Enter new weight:");

// Set up the input
                final EditText input = new EditText(this);
// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                builder.setView(input);

// Set up the buttons
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // update weight with new weight
                        if (dBHelper.updateWeight(arrayList.get(finalI).getID(), input.getText().toString())) {
                            arrayList.get(finalI).setWeight(input.getText().toString());
                            loadData();
                        } else {
                            Toast.makeText(DataGridActivity.this, "Error updating weight", Toast.LENGTH_LONG).show();
                        }

                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            });
            tableRow.addView(edit);
        }
    }

}